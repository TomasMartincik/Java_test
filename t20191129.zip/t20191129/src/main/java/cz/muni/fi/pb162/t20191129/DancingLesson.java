/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.muni.fi.pb162.t20191129;

import java.util.Set;
import java.util.HashSet;
import java.util.Arrays;
import java.util.stream.Collectors;

/**
 *
 * @author Tomas Martincik
 */
public class DancingLesson {
    private final Set<Dancer> dancers = new HashSet<>();
    
    public DancingLesson(Dancer[] dancers) {
        if (dancers == null) {
            throw new NullPointerException("given array of dancers is null");
        }
        for (Dancer dancer : dancers) {
            if (dancer == null) {
                throw new IllegalArgumentException("given array of dancers "
                        + "contains null");
            }
        }
        this.dancers.addAll(Arrays.asList(dancers));
    }
    
    public Dancer getDancer(int number) {
        for (Dancer dancer : this.dancers) {
            if (dancer.getNumber() == number) {
                return dancer;
            }
        }
        return null;
    }
    
    public boolean pair(int ladie, int gentleman) {
        Dancer lady = this.getDancer(ladie);
        if (lady == null) {
            return false;
        }
        Dancer man = this.getDancer(gentleman);
        if (man == null) {
            return false;
        }
        try {
            lady.setPartner(man);
        } catch (DancerException ex) {
            return false;
        }
        return true;
    }
    
    public boolean disjoin(int dancer) {
        Dancer pairMember = this.getDancer(dancer);
        if (pairMember == null) {
            return false;
        }
        return pairMember.unsetPartner();
    }
    
    public Set<Dancer> getSingles() {
        Set<Dancer> singles = this.dancers.stream()
                .filter(x -> x.hasPartner() == false)
                .collect(Collectors.toSet());
        return singles;
    }
}
