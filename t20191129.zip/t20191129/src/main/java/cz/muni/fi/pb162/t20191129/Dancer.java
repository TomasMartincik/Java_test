package cz.muni.fi.pb162.t20191129;

/**
 * Dancer.
 */
public class Dancer {

    private Dancer partner;
    private boolean female;
    private int number;

    /**
     * @param number dancer's number
     * @param isFemale if dancer is a female
     */
    public Dancer(int number, boolean isFemale) {
        this.number = number;
        female = isFemale;
    }

    /**
     * Creates dancing pair. This method assigns the given dancer as the
     * partner of this dancer and vice versa.
     *
     * @param partner Person to be assigned as the partner in dancing pair
     * @throws NullPointerException if the partner is null
     * @throws DancerException if either this dancer or the partner are already
     * in pair (they already have a partner)
     * @throws DancerException if this dancer and the given partner are of the
     * same gender
     */
    public void setPartner(Dancer partner) throws DancerException {
        if (partner == null) {
            throw new NullPointerException("partner is null");
        }
        if (this.hasPartner()) {
            throw new DancerException("this dancer already has a partner");
        }
        if (partner.hasPartner()) {
            throw new DancerException("other dancer already has a partner");
        }
        if (this.isFemale() == partner.isFemale()) {
            throw new DancerException("dancers are of the same gender");
        }
        partner.partner = this;
        this.partner = partner;
    }
    
    /**
     * @return true if the dancer has a partner
     */
    public boolean hasPartner() {
        return partner != null;
    }

    /**
     * @return true if the dancer is female
     */
    public boolean isFemale() {
        return female;
    }

    /**
     * @return true if the dancer is male
     */
    public boolean isMale() {
        return !female;
    }

    /**
     * @return number of the dancer
     */
    public int getNumber() {
        return number;
    }

    /**
     * Breaks the dancing pair, i.e. unsets partner of this dancer and vice
     * versa.
     *
     * @return false if this dancer had no partner.
     */
    public boolean unsetPartner() {
        if (!hasPartner()) {
            return false;
        }
        partner.partner = null;
        partner = null;
        return true;
    }

    @Override
    public String toString() {
        if (female) {
            return "Female dancer No. " + number;
        } else {
            return "Male dancer No. " + number;
        }
    }
    
    @Override
    public boolean equals(Object o) {
        if (o == null) {
            return false;
        }
        if (this.getClass() != o.getClass()) { 
            return false; 
        }
        Dancer that = (Dancer)o;
        return this.getNumber() == that.getNumber();
    }
    
    @Override
    public int hashCode() {
        return this.getNumber();
    } 
}
