package cz.muni.fi.res.introtest1_07;

public class Demo{
    public static void main(String[] args) {
        System.out.println(Group.MARC_AUREL);
        System.out.println(Group.VENUS);
        System.out.println(Group.ELSA);
        System.out.println(Group.FREDIE);
    }
}
