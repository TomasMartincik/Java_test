package cz.muni.fi.res.introtest1_07;

/**
 * Interface for lion creatures (i. e. lions, lioness and lionets (young lions and lioness')) objects.
 * @author   R.  Oslejsek   &   A.  Zlamal
 * @version 2013 10 19
 */
public interface LionCreature{
      /**
       * Gets the name of the object
       * 
       * @return the name of the object
       */
      String getName();
      
      /**
       * Gets the number of dependents of the objects. For example,
       * dependents of lions are lioness', dependents of lioness' are lionets
       * and lionets has no dependents.
       * 
       * @return Number of dependents
       */
      int getNumberOfDependents();
      
      /**
       * Gets "heading lion creature". For example,
       * the head object of a lioness is its lion, the head object
       * of a lionet is its mother == lioness, etc.
       */
     LionCreature getHead();
}
