package cz.muni.fi.res.introtest1_07;

/**
 *
 * @author Tomas Martincik
 */
public class Lioness extends LionAnimal {
    
    public Lioness(String name, LionCreature mate, int numOfLionets) {
        super(name, mate, numOfLionets);
    }
    
    public Lioness(String name, LionCreature mate) {
        this(name, mate, 0);
    }
    
    @Override
    public String toString() {
        return getName() + " female of " + getHead().getName() + " has "
                + getNumberOfDependents() + " lionet(s).";
    }
}
