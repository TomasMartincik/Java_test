package cz.muni.fi.res.introtest1_07;

/**
 *
 * @author Tomas Martincik
 */
public class LionAnimal implements LionCreature {
    private final String name;
    private final LionCreature head;
    private final int numOfDependents;
    
    public LionAnimal(String name, LionCreature head, int numOfDependents) {
        this.name = name;
        this.head = head;
        this.numOfDependents = numOfDependents;
    }
    
    @Override
    public String getName() {
        return name;
    }
    
    @Override
    public int getNumberOfDependents() {
        return numOfDependents;
    }
    
    @Override
    public LionCreature getHead() {
        return head;
    }
}
