package cz.muni.fi.res.introtest1_07;

/**
 *
 * @author Tomas Martincik
 */
public class Group {
    public static final LionCreature MARC_AUREL = new Lion("Marc Aurel",
            2, "barbary");
    public static final LionCreature VENUS = new Lioness("Venus", 
            Group.MARC_AUREL);
    public static final LionCreature ELSA = new Lioness("Elsa",
            Group.MARC_AUREL, 1);
    public static final LionCreature FREDIE = new Lionet("Fredie",
            Group.ELSA);
}
