package cz.muni.fi.res.introtest1_07;

/**
 *
 * @author Tomas Martincik
 */
public class Lion extends LionAnimal {
    private final String subSpecies;
    
    public Lion(String name, int numOfLioness, String subSpecies) {
        super(name, null, numOfLioness);
        this.subSpecies = subSpecies;
    }
    
    public String getSubSpecies() {
        return subSpecies;
    }
    
    @Override
    public String toString() {
        return getName() + " subspecie " + getSubSpecies() + " has "
                + getNumberOfDependents() + " lioness(').";
    }
}
