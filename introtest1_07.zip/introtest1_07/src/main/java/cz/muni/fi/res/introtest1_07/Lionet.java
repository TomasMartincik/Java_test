package cz.muni.fi.res.introtest1_07;

/**
 *
 * @author Tomas Martincik
 */
public class Lionet extends LionAnimal {
    private static final int NUMOFDEPENDENTS = 0;
    public Lionet(String name, LionCreature mother) {
        super(name, mother, NUMOFDEPENDENTS);
    }
    
    @Override
    public String toString() {
        return getName() + " is child of " + getHead().getName();
    }
}
